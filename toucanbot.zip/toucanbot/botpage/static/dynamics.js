function botToggle(){
    document.querySelector('.wrapper').classList.add('botActive')
}