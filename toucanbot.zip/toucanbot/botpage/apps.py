from django.apps import AppConfig


class BotpageConfig(AppConfig):
    name = 'botpage'
